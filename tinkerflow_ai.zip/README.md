# Tinkerflow-AI

## CLI Usage

Train model:
```
python tinkerflow.py train --epochs 1
```
