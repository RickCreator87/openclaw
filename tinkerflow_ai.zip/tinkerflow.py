#!/usr/bin/env python3
import argparse
from examples.train_mnist import train

def main():
    parser = argparse.ArgumentParser(prog="tinkerflow")
    subparsers = parser.add_subparsers(dest="command")

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--epochs", type=int, default=1)

    args = parser.parse_args()

    if args.command == "train":
        train(epochs=args.epochs)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
